import React, { useEffect, useState } from 'react'
import Sidebar from './Sidebar'
import Layout from '../layout/Layout'
import axios from 'axios'
import { toast } from 'react-toastify'
import DataTable from 'react-data-table-component'
import columns, { StudentButtons } from '../utils/StudentHelper'

export default function AllRecords() {
  let [students, setStudents] = useState([])
  const [id, setId] = useState("")
  const [name, setName] = useState("")
  const [course, setCourse] = useState("")
  const [city, setCity] = useState("")
  const [fees, setfees] = useState()


  const customStyles = {
    headCells: {
        style: {
            fontSize: '16px',
            fontWeight: "bold",
            textTransform:"capitalize"
        }
    }
}

  // handleUpdate
  const handleUpdate = async () => {
    //  console.log("ok")
    await axios.put(`http://localhost:3000/students/${id}`, {
      name, course, city, fees
    })
    toast.success("Record Updated!", { autoClose: 1000, "position": "top-center" })
    getRecords()
  }

  // getDetails
  const getDetails = (user) => {
    // console.log(user)
    setId(user?.id)
    setName(user?.name)
    setCourse(user?.course)
    setCity(user?.city)
    setfees(user?.fees)
  }

  const getData = (user) => {
    // console.log(user)
    setId(user?.id)
    setName(user?.name)
    setCourse(user?.course)
    setCity(user?.city)
    setfees(user?.fees)
  }

  // getRecords
  const getRecords = async () => {
    const res = await axios.get(`http://localhost:3000/students`)
    // console.log(res.data)
    if (res.status === 200) {
     const  records = res?.data?.map((student) =>
      (
        {

          _id: student?._id,
          name: student?.name,
          course: student?.course,
          city: student?.city,
          fees: student?.fees,
          action: <StudentButtons/>
        }
      )
      )
      console.log(records)
      setStudents(records)
    }
   
  }
  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:3000/students/${id}`)
    toast.success("Record deleted succesfully!", { autoClose: 1000, "position": "top-center" })
    setTimeout(() => {
      getRecords()
    }, 2000)

  }
  useEffect(() => {
    getRecords()
  }, [])
  return (
    <Layout>
      {/* view modal */}
      <div className="modal fade" id="viewModal" tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Student Personal Information
              </h1>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" />
            </div>
            <div className="modal-body">
              <table className="table table-borderless">
                <thead>

                </thead>
                <tbody>
                  <tr>
                    <th>Id</th>
                    <td>{id}</td>
                  </tr>
                  <tr>
                    <th>Name</th>
                    <td>{name}</td>
                  </tr>
                  <tr>
                    <th>Course</th>
                    <td>{course}</td>
                  </tr>
                  <tr>
                    <th>Fees</th>
                    <td>{fees}</td>
                  </tr>
                </tbody>
              </table>

            </div>
            <div className="modal-footer">

            </div>
          </div>
        </div>
      </div>


      {/* edit modal */}
      <div className="modal fade" id="editModal" tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">Edit User Details </h1>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" />
            </div>
            <div className="modal-body">
              <form>
                <div className='form-group'>
                  <label htmlFor="">Name</label>
                  <input type="text" className='form-control'
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor="">Course</label>
                  <input type="text" className='form-control'
                    value={course}
                    onChange={(e) => setCourse(e.target.value)}
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor="">City</label>
                  <input type="text" className='form-control'
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor="">Fees</label>
                  <input type="text" className='form-control'
                    value={fees}
                    onChange={(e) => setfees(e.target.value)}
                  />
                </div>
              </form>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-success w-100" data-bs-dismiss="modal"
                onClick={handleUpdate}
              >
                Update
              </button>

            </div>
          </div>
        </div>
      </div>



      <div className='container-fluid my-3'>
        <div className='row'>
          <div className='col-md-3'>
            <Sidebar />
          </div>
          <div className='col-md-9'>
            <h4 className='text-center mb-2'>List of students</h4>
            {/* <table className="table table-bordered">
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Course</th>
                  <th scope="col">City</th>
                  <th scope="col">Fees</th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                {
                  students?.map((student) => <tr key={student.id}>
                    <td>{student.name.toUpperCase()}</td>
                    <td>{student.course}</td>
                    <td>{student.city}</td>
                    <td>{student.fees}</td>
                    <td>
                      <button className='btn btn-sm btn-success mx-1'
                        data-bs-toggle="modal"
                        data-bs-target="#editModal"
                        onClick={() => getDetails(student)}
                      >
                        Edit
                      </button>




                      <button className='btn btn-sm btn-danger mx-1'
                        onClick={() => {
                          if (confirm("Are you sure to delete?")) {
                            handleDelete(student?.id)
                          }
                        }}
                      >
                        Delete
                      </button>
                      <button className='btn btn-sm btn-warning'
                        data-bs-toggle="modal"
                        data-bs-target="#viewModal"
                        onClick={() => getData(student)}
                      >
                        View
                      </button>
                    </td>
                  </tr>)
                }

              </tbody>
            </table> */}


            <DataTable
              columns={columns}
              data={students}
              pagination
              paginationPerPage={5}
              paginationRowsPerPageOptions={[5,10,15,20,25,30]}
              customStyles={customStyles}
            />


          </div>
        </div>
      </div>
    </Layout>
  )
}
