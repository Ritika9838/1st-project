import React, { useState } from 'react'
import Layout from '../layout/Layout'
import { NavLink, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { toast } from 'react-toastify'

export default function Login() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const navigate = useNavigate()
  const handleLogin = async (e) => {
    e.preventDefault()
    let { data } = await axios.get(`http://localhost:3000/users`)
    let users = data;
    let flag;
    for (let i = 0; i < users.length; ++i) {
      if (email === users[i].email && password === users[i].password) {
        flag = 1
        localStorage.setItem("auth",JSON.stringify(users[i]));
        break;
      }
      else {
        flag = 0
      }
    }
    if (flag === 1) {
      toast.success("Login successfull!", { autoClose: 1000 })
      setTimeout(() => {
        navigate("/profile")
      }, 2000)

    }
    else {
      toast.error("Invalid credentials!", { autoClose: 1000 })
    }
  }
  return (
    <Layout>
      <div className='container'>
        <div className='row'>
          <div className='col-md-3'></div>
          <div className='col-md-6'>
            <div className='card p-5 my-5'>
              <form onSubmit={handleLogin}>
                <h2 className='mb-3'>Login Form</h2>

                <div className='form-group'>
                  <label htmlFor="">Email</label>
                  <input
                    type="text"
                    className='form-control'
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}

                  />
                </div>

                <div className='form-group'>
                  <label htmlFor="">Password</label>
                  <input
                    type="password"
                    className='form-control'
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete='off'
                  />
                </div>

                <div className='form-group mt-2'>
                  <button className='btn btn-primary w-100'>Login</button>
                </div>

                <p className='mt-3'>If not registered! <NavLink to="/register">
                  click here</NavLink></p>
              </form>
            </div>

          </div>
          <div className='col-md-3'></div>
        </div>
      </div>
    </Layout>
  )
}
