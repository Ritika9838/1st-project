import React from 'react'
import { NavLink } from 'react-router-dom'

function Sidebar() {
    return (
        <div className="list-group">
            <h4 className='text-white bg-secondary p-2'>User Dashboard</h4>
            <NavLink to="/profile" 
            className="list-group-item list-group-item-action" aria-current="true">
                Profile
            </NavLink>
            <NavLink to="/add-record" className="list-group-item list-group-item-action">
                Add Record
            </NavLink>
            <NavLink to="/all-records" className="list-group-item list-group-item-action rounded-0">
                All Records
            </NavLink>
        </div>

    )
}

export default Sidebar