import React, { useState } from 'react'
import Layout from '../layout/Layout'
import axios from 'axios'
import { toast } from 'react-toastify'
import { NavLink, useNavigate } from 'react-router-dom'

export default function Register() {
  const navigate = useNavigate()

  const [data, setData] = useState(
    { name: "", email: "", image: "", password: "" }
  )
  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value })

  }
  const handleImage = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const base64Image = reader.result;
        setData({ ...data, image: base64Image })
      }
      reader.readAsDataURL(file);
    }
  }
  const handleSubmit = async (e) => {
    e.preventDefault()
    const res = await axios.post(`http://localhost:3000/users`, data)
    toast.success("Regiseration successful!",{autoClose:1000})
    setTimeout(()=>{
       navigate("/login")
    },2000)
  }
  return (
    <Layout>
      <div className='container'>
        <div className='row'>
          <div className='col-md-3'></div>
          <div className='col-md-6'>
            <div className='card p-5 my-3'>
              <form encType="multipart/form-data" onSubmit={handleSubmit}>
                <h2 className='mb-3'>Registeration Form</h2>
                <div className='form-group'>
                  <label htmlFor="">Name</label>
                  <input
                    type="text"
                    className='form-control'
                    name='name'
                    value={data.name}
                    onChange={handleChange}
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor="">Email</label>
                  <input
                    type="text"
                    className='form-control'
                    name='email'
                    value={data.email}
                    onChange={handleChange}
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor="">Image</label>
                  <input type="file"
                    className='form-control'
                    name='image'
                    accept='/*'
                    onChange={handleImage}
                  />
                </div>
                <div className='form-group'>
                  <label htmlFor="">Password</label>
                  <input
                    type="password"
                    className='form-control'
                    name='password'
                    value={data.password}
                    onChange={handleChange}
                  />
                </div>
                <div className='form-group mt-2'>
                  <button className='btn btn-primary w-100'>
                    Register
                  </button>
                </div>
              </form>
              <p className='mt-3'>Already registered! <NavLink to="/login">
                              click here</NavLink></p>
            </div>

          </div>
          <div className='col-md-3'></div>
        </div>
      </div>
    </Layout>
  )
}
