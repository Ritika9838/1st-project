import React from 'react'
import Layout from '../layout/Layout'

export default function Home() {
  return (
    
        <Layout>
            
           Home Page

        </Layout>
    
  )
}
