import React, { useState } from 'react'
import Sidebar from './Sidebar'
import Layout from '../layout/Layout'
import axios from 'axios'
import { toast } from 'react-toastify'
import { useNavigate } from 'react-router-dom'

export default function AddRecord() {
    const navigate = useNavigate()
    const [data, setData] = useState({
        name: "", city: "", course: "", fees: ""
    })

    const handleChange = (e)=>{
        setData({...data,[e.target.name]:e.target.value})
    }

    const handleSubmit = async(e) => {
        e.preventDefault()
        try {
            await axios.post(`http://localhost:3000/students`,data)
            toast.success("New Student Added!",{autoClose:1000,"position":"top-center"})
            setTimeout(()=>{
                 navigate("/all-records")
            },2000)

        } catch (error) {
            console.log(error)
        }
    }
    return (
        <Layout>
            <div className='container-fluid my-3'>
                <div className='row'>
                    <div className='col-md-3'>
                        <Sidebar />
                    </div>
                    <div className='col-md-9'>
                        <h5 className='mb-3 text-primary'>Student Detials Form</h5>
                        <form className='w-50' onSubmit={handleSubmit}>
                            <div className='form-group'>
                                <label htmlFor="">Name</label>
                                <input
                                    type="text"
                                    className='form-control'
                                    name="name"
                                    value={data?.name}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className='form-group'>
                                <label htmlFor="">City</label>
                                <input type="text" className='form-control'
                                    name="city"
                                    value={data?.city}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className='form-group'>
                                <label htmlFor="">Course</label>
                                <input type="text" className='form-control'
                                    name="course"
                                    value={data?.course}
                                    onChange={handleChange}

                                />
                            </div>
                            <div className='form-group'>
                                <label htmlFor="">Fees</label>
                                <input type="text" className='form-control'
                                    name="fees"
                                    value={data?.fees}
                                    onChange={handleChange}

                                />
                            </div>
                            <div>
                                <button className='btn btn-secondary w-100 mt-3'>
                                    Add Student 
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </Layout>
    )
}
