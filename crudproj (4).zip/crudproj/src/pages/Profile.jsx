import React from 'react'
import Layout from '../layout/Layout'
import Sidebar from './Sidebar';

export default function Profile() {
  const data = localStorage.getItem("auth")
  const parseData = JSON.parse(data);
  return (
    <Layout>
      <div className='container-fluid my-3'>
        <div className='row'>
          <div className='col-md-3'>
            <Sidebar />
          </div>
          <div className='col-md-9 d-flex gap-5'>
            <table className="table table-bordered w-50 ">
              <caption>Personal Details</caption>
              <thead>
                <tr>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">Id</th>
                  <td>{parseData?.id}</td>
                </tr>
                <tr>
                  <th scope="row">Name</th>
                  <td>{parseData?.name.toUpperCase()}</td>
                </tr>
                <tr>
                  <th scope="row">Email</th>
                  <td>{parseData?.email}</td>
                </tr>
                <tr>
                  <th scope="row">Password</th>
                  <td>*******</td>
                </tr>
                
              </tbody>
            </table>
           
               <div>
                  <img src={parseData?.image} alt="" 
                   style={{borderRadius:"50%",height:"250px",width:"250px"}}
                  />
               </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}
