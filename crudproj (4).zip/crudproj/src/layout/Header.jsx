import React from 'react'
import Navbar1 from './Navbar1'

export default function Header() {
  return (
    <div>
      <Navbar1></Navbar1>
    </div>
  )
}
