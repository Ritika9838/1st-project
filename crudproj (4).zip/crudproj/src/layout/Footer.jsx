import React from 'react'

export default function Footer() {
  return (
    <div>
      <h4 className='text-center bg-light p-3'>
            atpronTechnology&copy;tech.in
        </h4>
    </div>
  )
}
