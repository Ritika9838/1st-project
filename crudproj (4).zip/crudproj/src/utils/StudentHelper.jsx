const columns =[
    {
        name:"name",
        selector:(row)=>row.name,
        sortable:true,
        width:"120px"
    },
    {
        name:"course",
        selector:(row)=>row.course,
        sortable:true,
        width:"120px"
    },
    {
        name:"city",
        selector:(row)=>row.city,
        sortable:true,
        width:"120px"
    },
    {
        name:"fees",
        selector:(row)=>row.fees,
        sortable:true,
        width:"120px"
    },
    {
        name:"Actions",
        selector:(row)=>row.action,
       
    }
]
export default columns;


const StudentButtons =()=>{
    return (
    <div>
        <button className="btn btn-success btn-sm mx-1">Edit</button>
        <button className="btn btn-danger btn-sm mx-1">Delete</button>
        <button className="btn btn-warning btn-sm mx-1">View</button>
    </div>
    )
}

export {StudentButtons}