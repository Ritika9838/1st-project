
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css'
import Register from './pages/Register'
import Home from './pages/Home'
import Login from './pages/Login'
import Pagenotfound from './pages/Pagenotfound'
import { ToastContainer } from 'react-toastify'
import Profile from './pages/Profile'
import AllRecords from './pages/AllRecords'
import AddRecord from './pages/AddRecord'
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/register' element={<Register/>} />
          <Route path='/login' element={<Login/>} />
          <Route path='/profile' element={<Profile/>} />
          <Route path='/all-records' element={<AllRecords/>} />
          <Route path='/add-record' element={<AddRecord/>} />
          <Route path='*' element={<Pagenotfound/>} />
        </Routes>
        <ToastContainer/>
      </BrowserRouter>
    </>
  )
}

export default App
